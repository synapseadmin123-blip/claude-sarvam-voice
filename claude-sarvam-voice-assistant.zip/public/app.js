const $ = id => document.getElementById(id);
const promptBox = $("prompt"), chatBox = $("chat"), welcome = $("welcome");
let messages = [], busy = false, recognition = null, audioPlayer = null;

function setBusy(value) { busy = value; $("send").disabled = value; $("send").textContent = value ? "…" : "↑"; }
function showChat() { welcome.style.display = "none"; chatBox.style.display = "block"; }
function addMessage(role, text) {
  showChat();
  const row = document.createElement("div"); row.className = `message ${role}`;
  const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = role === "assistant" ? "✳" : "●";
  const body = document.createElement("div"); body.className = "bubble"; body.textContent = text;
  row.append(avatar, body); chatBox.append(row); row.scrollIntoView({ behavior: "smooth", block: "end" });
  return body;
}
async function sendMessage(text) {
  text = text.trim(); if (!text || busy) return;
  promptBox.value = ""; promptBox.style.height = "auto";
  messages.push({ role: "user", content: text }); addMessage("user", text); setBusy(true);
  try {
    const r = await fetch("/api/chat", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({messages}) });
    const data = await r.json(); if (!r.ok) throw new Error(data.error || "Chat request failed.");
    messages.push({ role:"assistant", content:data.answer });
    const bubble = addMessage("assistant", data.answer);
    const speak = document.createElement("button"); speak.className = "speak-btn"; speak.textContent = "🔊  Play voice"; speak.onclick = () => speakText(data.answer);
    bubble.append(speak);
  } catch (e) { addMessage("assistant", `Sorry — ${e.message}`); }
  finally { setBusy(false); promptBox.focus(); }
}
async function speakText(text) {
  try {
    const r = await fetch("/api/speak", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({text, language:$("language").value}) });
    const data = await r.json(); if (!r.ok) throw new Error(data.error || "Speech failed.");
    if (!data.audio) throw new Error("No audio was returned.");
    if (audioPlayer) { audioPlayer.pause(); URL.revokeObjectURL(audioPlayer.src); }
    const bytes = Uint8Array.from(atob(data.audio), c => c.charCodeAt(0));
    audioPlayer = new Audio(URL.createObjectURL(new Blob([bytes], {type:data.mimeType || "audio/mpeg"})));
    await audioPlayer.play();
  } catch(e) { addMessage("assistant", `Voice error: ${e.message}`); }
}
$("send").onclick = () => sendMessage(promptBox.value);
promptBox.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(promptBox.value); } });
promptBox.addEventListener("input", () => { promptBox.style.height = "auto"; promptBox.style.height = Math.min(promptBox.scrollHeight,180) + "px"; });
$("newChat").onclick = () => { messages=[]; chatBox.innerHTML=""; chatBox.style.display="none"; welcome.style.display="block"; };
document.querySelectorAll(".suggestions button").forEach(b => b.onclick = () => sendMessage(b.textContent));

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  recognition = new SpeechRecognition(); recognition.continuous = false; recognition.interimResults = true;
  recognition.onresult = event => {
    let finalText = "", interim = "";
    for (let i=event.resultIndex; i<event.results.length; i++) {
      if (event.results[i].isFinal) finalText += event.results[i][0].transcript;
      else interim += event.results[i][0].transcript;
    }
    promptBox.value = finalText || interim;
    if (finalText) sendMessage(finalText);
  };
  recognition.onend = () => $("mic").classList.remove("listening");
  recognition.onerror = () => $("mic").classList.remove("listening");
  $("mic").onclick = () => {
    recognition.lang = $("language").value === "hi-IN" ? "hi-IN" : $("language").value;
    $("mic").classList.add("listening"); recognition.start();
  };
} else {
  $("mic").onclick = () => alert("Voice input is not supported in this browser. Try Chrome on Android or desktop.");
  $("mic").title = "Voice input requires a browser with Web Speech support";
}