import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

const requireKeys = () => {
  if (!process.env.ANTHROPIC_API_KEY || !process.env.SARVAM_API_KEY) {
    throw new Error("Add ANTHROPIC_API_KEY and SARVAM_API_KEY to your .env file.");
  }
};

app.post("/api/chat", async (req, res) => {
  try {
    requireKeys();
    const { messages } = req.body;
    if (!Array.isArray(messages) || !messages.length) {
      return res.status(400).json({ error: "A conversation is required." });
    }
    const safeMessages = messages.slice(-24).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 12000)
    }));
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: process.env.CLAUDE_MODEL || "claude-sonnet-4-6",
        max_tokens: 1200,
        system: "You are a warm, capable voice-first assistant. Reply naturally and concisely, suitable for being spoken aloud. Match the user's language; understand Hindi, English and Hinglish. Avoid markdown tables unless asked.",
        messages: safeMessages
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || "Claude request failed." });
    const answer = (data.content || []).filter(x => x.type === "text").map(x => x.text).join("\n").trim();
    res.json({ answer });
  } catch (e) {
    res.status(500).json({ error: e.message || "Server error." });
  }
});

app.post("/api/speak", async (req, res) => {
  try {
    requireKeys();
    const { text, language = "hi-IN", speaker = "shubh_enhi_ads" } = req.body;
    const clean = String(text || "").trim().slice(0, 2500);
    if (!clean) return res.status(400).json({ error: "Text is required." });
    const response = await fetch("https://api.sarvam.ai/text-to-speech", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "api-subscription-key": process.env.SARVAM_API_KEY
      },
      body: JSON.stringify({
        text: clean,
        model: "bulbul:v4-flash",
        language_code: language,
        speaker,
        output_audio_codec: "mp3",
        pace: 1.0
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.message || data.error || "Sarvam speech generation failed." });
    res.json({ audio: data.audios?.[0], mimeType: "audio/mpeg" });
  } catch (e) {
    res.status(500).json({ error: e.message || "Server error." });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Voice assistant running at http://localhost:${port}`));