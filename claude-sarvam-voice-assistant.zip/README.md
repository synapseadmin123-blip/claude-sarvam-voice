# Claude + Sarvam Voice Assistant

A starter voice-first web app:
- Browser speech recognition for voice input (Chrome recommended).
- Claude Messages API for conversational intelligence.
- Sarvam Bulbul v4 Flash for spoken replies.
- Hindi, English, Hinglish and additional Indian-language speech options.

## Requirements
- Node.js 18+
- Claude API key from https://platform.claude.com/settings/keys
- Sarvam API key from https://dashboard.sarvam.ai/

## Run locally
1. Extract the ZIP and open this folder in a terminal.
2. Install packages:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env`.
4. Put your keys in `.env`:
   ```env
   ANTHROPIC_API_KEY=sk-ant-...
   SARVAM_API_KEY=...
   CLAUDE_MODEL=claude-sonnet-4-6
   PORT=3000
   ```
5. Start:
   ```bash
   npm start
   ```
6. Open http://localhost:3000

## Important
- Never put API keys in `public/` or frontend JavaScript. The Express server keeps them on the server.
- Use HTTPS when deploying; microphone access generally requires localhost or a secure context.
- Browser voice recognition support varies. Chrome on Android/desktop is recommended; the app still supports typed chat where recognition is unavailable.
- The speech endpoint accepts up to 2,500 characters per request. This starter speaks the full answer when it fits; long answers may need splitting into chunks.
- The selected speech language guides Sarvam TTS. For best Hinglish pronunciation, use Devanagari for Hindi words where practical.
- API usage may incur charges according to your Claude and Sarvam accounts.

## API references
- Sarvam TTS REST: https://docs.sarvam.ai/api/api-guides-tutorials/text-to-speech/rest-api
- Sarvam TTS overview: https://docs.sarvam.ai/api/api-guides-tutorials/text-to-speech/overview
- Claude Messages API: https://platform.claude.com/docs/en/api/messages/create
